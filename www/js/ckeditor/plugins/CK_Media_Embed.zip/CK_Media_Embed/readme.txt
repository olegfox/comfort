Installing the MediaEmbed Plugin

1. Copy the "mediaembed" folder and place it in the ~/ckeditor/plugins directory.

2. Enable the plugin by changing or adding the extraPlugins line in your configuration (config.js):

    config.extraPlugins = 'MediaEmbed';

3. Add the button to your toolbar by adding the 'MediaEmbed' item to the list.

That's it, overall pretty simple.  This plugin could also be used for inserting custom code snippets, or pretty much anything that requires a custom insert.  Enjoy!
